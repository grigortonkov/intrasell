ALTER TABLE `intrasell_daten_2`.`grartikel-vertriebskosten`
ADD COLUMN `ArtNr` INT(10);
