﻿ALTER TABLE  `grartikel-kategorien` ADD COLUMN `keywords` LONGTEXT  ,
 ADD COLUMN `Description` LONGTEXT;
