-- Profil 
CREATE TABLE  `ofAdressen-profil` (
  `ID` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  `IDNR` INT(10) NOT NULL,
  `Name` VARCHAR(255) NOT NULL,
  `Wert` VARCHAR(2000),
  `AngelegtAm` TIMESTAMP NOT NULL,
  PRIMARY KEY (`ID`)
)
ENGINE = InnoDB;

-- Done