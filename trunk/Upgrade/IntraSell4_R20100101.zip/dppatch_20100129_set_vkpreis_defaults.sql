ALTER TABLE `grartikel-vkpreisperselection` MODIFY COLUMN `ArtNr` INT(10) DEFAULT '-1';
