﻿ALTER TABLE  `ofadressen` ADD COLUMN `UIDGeprueftAm` DATETIME AFTER `BHReferenz`;
