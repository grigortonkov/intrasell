
VB RezQ - Source Recovery for Visual Basic
==========================================

Lost your Visual Basic source files?... 

...Call VB RezQ to your rescue! 
VB RezQ saves you time and effort. Let VB RezQ help you re-write your 
program by re-creating your source files from the data that's hidden 
inside the compiled file. 


RELEASE NOTES - Demo Version
============================

Thank you for evaluating our demo version of VB RezQ.

This demo version has all the features of the full version but is 
limited to recover only the project file (.vbp) and one source 
file (usually a .frm). 

More information about the full version is available on our 
web site - http://www.vbrezq.com/

CAPABILITIES OF THE FULL VERSION OF VB REZQ

VB RezQ provides an accurate framework on which you can rebuild your 
VB application. It identifies all the source files, recovers the 
project file, the graphical design of each form including the 
graphics themselves, references to custom controls and declarations 
for API calls. It also identifies all events and subroutines and 
embedded resources.

VB RezQ can recover source from all types of 32-bit Visual Basic 
executables i.e .exe, .ocx and .dll files created by VB4(32), VB5 
and VB6.  

KNOWN LIMITATIONS

VB RezQ produces empty subroutines - it does not recover the source 
code within subroutines. For native compiled executables, it can 
provide a disassembly of the native x86 code.

The operation of VB RezQ relies on an understanding of the internal 
format of compiled Visual Basic executable files. There is no 
publicly available definition of this format. A tedious process of 
compiling test programs and inspecting the result has allowed much 
of it to be deduced. It is unlikely, however, that this testing has 
covered every possible aspect and it is to be expected that the 
occasional executable will cause problems for VB RezQ.

You can find more information about the full version by visiting our 
web site - http://www.vbrezq.com/


Copyright � 2006 ThunderPeek Software, England
All Rights Reserved.



