ALTER TABLE `intrasell_daten_2`.`mailstosend` ADD INDEX `Index_Priority`(`Priority`);
